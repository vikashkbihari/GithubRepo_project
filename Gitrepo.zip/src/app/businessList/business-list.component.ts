import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-business-list-component',
  templateUrl: './business-list.component.html',
  styleUrls: ['./business-list.component.css']
})
export class businessList implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
