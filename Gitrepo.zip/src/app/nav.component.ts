import { Component } from '@angular/core';

@Component({
    selector: 'nav-select',
    templateUrl: './nav.component.html',
    styleUrls: ['./nav.component.css','./bootstrap/css/bootstrap.min.css','./includes/css/bootstrap-glyphicons.css']
  })
  export class NavComponent {

  }