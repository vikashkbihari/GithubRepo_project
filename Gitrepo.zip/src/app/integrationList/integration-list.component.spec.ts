import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { integrationList } from './integration-list.component';

describe('IntegrationListComponentComponent', () => {
  let component: integrationList;
  let fixture: ComponentFixture<integrationList>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ integrationList ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(integrationList);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
